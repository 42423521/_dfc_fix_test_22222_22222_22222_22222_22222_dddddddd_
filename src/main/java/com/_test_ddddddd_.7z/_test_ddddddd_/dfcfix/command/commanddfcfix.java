package com._test_ddddddd_.dfcfix.command;

import com._test_ddddddd_.dfcfix.ExplosionControl;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.TextComponentString;

import java.util.ArrayList;
import java.util.List;

public class CommandDfcFix extends CommandBase {
    @Override
    public String getName() {
        return "dfcfix";
    }

    @Override
    public String getUsage(ICommandSender sender) {
        return "/dfcfix explosions <on|off|toggle|status>";
    }

    @Override
    public void execute(MinecraftServer server, ICommandSender sender, String[] args) {
        if (args.length == 0) {
            sender.sendMessage(new TextComponentString("Usage: " + getUsage(sender)));
            return;
        }

        String sub = args[0].toLowerCase();
        switch (sub) {
            case "on":
                ExplosionControl.setBlockExplosions(true);
                sender.sendMessage(new TextComponentString("[dfcfix] Block explosions = ON"));
                break;
            case "off":
                ExplosionControl.setBlockExplosions(false);
                sender.sendMessage(new TextComponentString("[dfcfix] Block explosions = OFF"));
                break;
            case "toggle":
                ExplosionControl.toggle();
                sender.sendMessage(new TextComponentString("[dfcfix] Block explosions toggled. Now = " + ExplosionControl.isBlockExplosions()));
                break;
            case "status":
                sender.sendMessage(new TextComponentString("[dfcfix] Block explosions = " + ExplosionControl.isBlockExplosions()));
                break;
            default:
                sender.sendMessage(new TextComponentString("Unknown subcommand. " + getUsage(sender)));
                break;
        }
    }

    @Override
    public List<String> getTabCompletions(MinecraftServer server, ICommandSender sender, String[] args, net.minecraft.util.math.BlockPos targetPos) {
        if (args.length == 1) {
            List<String> l = new ArrayList<>();
            l.add("on");
            l.add("off");
            l.add("toggle");
            l.add("status");
            return getListOfStringsMatchingLastWord(args, l);
        }
        return super.getTabCompletions(server, sender, args, targetPos);
    }

    @Override
    public int getRequiredPermissionLevel() {
        // 0 = anyone, 2 = ops; 2 更安全
        return 2;
    }
}
