package com._test_ddddddd_.dfcfix.dfcmod;

/**
 * 初始化 Mixin（如果你在项目里用到 mixin）
 *
 * 兼容 1.12 环境下的 Mixin 初始化方式：
 * MixinBootstrap.init();
 * Mixins.addConfiguration("mixins.dfcfix.json");
 *
 * 如果没有引入 mixin runtime（或 RFG 在运行时自动注入）也不会崩溃，这里捕获异常打印。
 */
public class DfcMixinLoader {
    public static void init() {
        try {
            // runtime classes
            Class.forName("org.spongepowered.asm.launch.MixinBootstrap");
            // call MixinBootstrap.init()
            org.spongepowered.asm.launch.MixinBootstrap.init();
            org.spongepowered.asm.mixin.Mixins.addConfiguration("mixins.dfcfix.json");
        } catch (Throwable t) {
            // 如果 mixin 库不可用（例如没有在运行时注入），打印日志但不抛出
            t.printStackTrace();
        }
    }
}
