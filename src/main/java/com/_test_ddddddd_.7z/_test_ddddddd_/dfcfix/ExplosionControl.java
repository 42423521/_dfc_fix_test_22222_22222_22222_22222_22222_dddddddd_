package com._test_ddddddd_.dfcfix;

import net.minecraft.util.text.TextComponentString;
import net.minecraftforge.event.world.ExplosionEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

/**
 * 一个非常简单的爆炸控制器：
 * 默认开启阻止爆炸（可由命令切换）
 *
 * 注意：取消 ExplosionEvent.Start 会阻止爆炸发生。
 */
public class ExplosionControl {
    // 默认：不开启爆炸（true 表示阻止爆炸）
    private static boolean blockExplosions = false;

    public static boolean isBlockExplosions() {
        return blockExplosions;
    }

    public static void setBlockExplosions(boolean block) {
        blockExplosions = block;
    }

    public static void toggle() {
        blockExplosions = !blockExplosions;
    }

    @SubscribeEvent
    public void onExplosionStart(ExplosionEvent.Start event) {
        if (blockExplosions) {
            // Cancel 会阻止接下来的爆炸逻辑
            event.setCanceled(true);
        }
    }
}
