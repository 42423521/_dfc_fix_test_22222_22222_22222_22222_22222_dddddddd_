






//////////////变了类型好办直接引用， 完全没了还要找，改， 别人前面写了引用，为什么后面会相对出问题
























//////////////////////////////package your.package.mixin;


package com._test_ddddddd_.dfcfix.mixin;

import net.minecraft.item.ItemStack;
import com.hbm.items.machine.ItemLens;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * 给 ItemLens 注入一个公共字段 maxDamage（如果运行时不存在的话）。
 * 同时在构造完毕时尝试把真实值同步到该字段（反射或调用 getter）。
 *
 * 目的：避免其他 mod/原有代码对 lens.maxDamage 的 GETFIELD 抛 NoSuchFieldError。
 */
@Mixin(ItemLens.class)
public abstract class _mixin_item_lens_rnm_qm_yy_l_d_lj_gpt_ddddddddd_{//.java//MixinItemLens {

    /**
     * 新增字段（Unique 确保不会与目标类已有字段冲突）
     * 这里声明为 public，供原始字节码的 GETFIELD 访问。
     */
    @Unique
    public int maxDamage = 0;

    /**
     * 在目标类构造后尝试初始化 maxDamage 的值（以提高兼容性）。
     * 注：ItemLens 可能会有 getMaxDamage(...) 或父类方法可用，或者有私有字段存真值。
     */
    @Inject(method = "<init>", at = @At("RETURN"))
    private void onConstruct(CallbackInfo ci) {
        try {
            // 优先通过目标类自身的 getter(s)
            try {
                Method m = this.getClass().getMethod("getMaxDamage", ItemStack.class);
                // 调用时没有 ItemStack，尝试无参版本
                Object r = null;
                try {
                    r = m.invoke(this, (Object) null);
                } catch (IllegalArgumentException iae) {
                    // 有些实现需要 ItemStack 参数 -> 忽略此步骤
                }
                if (r instanceof Number) {
                    this.maxDamage = ((Number) r).intValue();
                    return;
                }
            } catch (NoSuchMethodException ignored) {}

            try {
                Method m0 = this.getClass().getMethod("getMaxDamage");
                Object r0 = m0.invoke(this);
                if (r0 instanceof Number) {
                    this.maxDamage = ((Number) r0).intValue();
                    return;
                }
            } catch (NoSuchMethodException ignored) {}

            // 如果没有公开 getter，再尝试扫描目标类的 declared fields（寻找含 "max" 的 int 字段）
            Class<?> cls = this.getClass();
            for (Field f : cls.getDeclaredFields()) {
                if (f.getType() == int.class) {
                    String n = f.getName().toLowerCase();
                    if (n.contains("max") || n.contains("dur") || n.contains("field_")) {
                        try {
                            f.setAccessible(true);
                            Object val = f.get(this);
                            if (val instanceof Integer) {
                                this.maxDamage = (Integer) val;
                                return;
                            }
                        } catch (Throwable t) {
                            // 读取失败继续尝试下一个
                        }
                    }
                }
            }
        } catch (Throwable t) {
            // 保守处理：不要把异常抛回去，防止 mixin 校验/类加载失败
            t.printStackTrace();
        }
    }
}
