











































































































































package com._test_ddddddd_.dfcfix.mixin;

import com.hbm.packet.AuxGaugePacket;
import com.hbm.packet.PacketDispatcher;
import com.hbm.tileentity.machine.TileEntityCoreStabilizer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.network.NetworkRegistry.TargetPoint;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(TileEntityCoreStabilizer.class)
public abstract class MixinTileEntityCoreStabilizer {

    @Overwrite
    public void update() {
        TileEntityCoreStabilizer self = (TileEntityCoreStabilizer) (Object) this;

        if (!self.getWorld().isRemote) {
            self.updateStandardConnections(self.getWorld(), self.getPos());

            self.watts = MathHelper.clamp(self.watts, 1, 100);
            long demand = (long) Math.pow(self.watts, 6);
            self.isOn = false;

            self.beam = 0;

            ItemStack stack = self.inventory.getStackInSlot(0);
            com.hbm.items.machine.ItemLens lens = null;
            if (stack != null && !stack.isEmpty() && stack.getItem() instanceof com.hbm.items.machine.ItemLens) {
                lens = (com.hbm.items.machine.ItemLens) stack.getItem();
            }

            if (lens != null && self.power >= demand * lens.drainMod) {
                self.isOn = true;
                EnumFacing dir = EnumFacing.byIndex(self.getBlockMetadata());
                for (int i = 1; i <= TileEntityCoreStabilizer.range; i++) {

                    int x = self.getPos().getX() + dir.getXOffset() * i;
                    int y = self.getPos().getY() + dir.getYOffset() * i;
                    int z = self.getPos().getZ() + dir.getZOffset() * i;
                    BlockPos pos1 = new BlockPos(x, y, z);

                    net.minecraft.tileentity.TileEntity te = self.getWorld().getTileEntity(pos1);
                    if (te != null && te.getClass().getName().equals("com.hbm.tileentity.machine.TileEntityCore")) {

                        // try to update core.field via reflection (safe)
                        try {
                            java.lang.reflect.Field field = te.getClass().getDeclaredField("field");
                            field.setAccessible(true);
                            int cur = field.getInt(te);
                            field.setInt(te, cur + (int) (self.watts * lens.fieldMod));
                        } catch (Throwable ignored) {}

                        self.power -= (long) (demand * lens.drainMod);
                        self.beam = i;

                        long dmg = com.hbm.items.machine.ItemLens.getLensDamage(stack);
                        dmg += self.watts;

                        // --- COMPAT: determine max safely ---
                        int max = com._test_ddddddd_.dfcfix.util.LensCompat.getMaxDamageSafe(stack.getItem(), stack);

                        // Print diagnostics (three sources)
                        try {
                            System.out.println("[DIAG] lens.maxDamage (field) = " + (lens != null ? lens.maxDamage : "N/A"));
                        } catch (Throwable ignored) {}
                        try {
                            System.out.println("[DIAG] stack.getMaxDamage() = " + stack.getMaxDamage());
                        } catch (Throwable ignored) {}
                        try {
                            System.out.println("[DIAG] ItemLens.getLensDamage(stack) = " + com.hbm.items.machine.ItemLens.getLensDamage(stack));
                        } catch (Throwable ignored) {}

                        // safety: only remove if we have a positive max
                        if (max > 0) {
                            if (dmg >= max)
                                self.inventory.setStackInSlot(0, ItemStack.EMPTY);
                            else
                                com.hbm.items.machine.ItemLens.setLensDamage(stack, dmg);
                        } else {
                            // unknown max -> don't delete, just write back damage value
                            com.hbm.items.machine.ItemLens.setLensDamage(stack, dmg);
                            System.err.println("[CoreStab] Warning: unknown lens maxDamage (0). Skipping removal.");
                        }

                        break;
                    }

                    if (self.getWorld().getTileEntity(pos1) instanceof TileEntityCoreStabilizer)
                        continue;

                    if (self.getWorld().getBlockState(pos1).getBlock() != Blocks.AIR)
                        break;
                }
            }

            PacketDispatcher.wrapper.sendToAllTracking(new AuxGaugePacket(self.getPos(), self.beam, 0),
                    new TargetPoint(self.getWorld().provider.getDimension(), self.getPos().getX(), self.getPos().getY(), self.getPos().getZ(), 250));
        }
    }
}
