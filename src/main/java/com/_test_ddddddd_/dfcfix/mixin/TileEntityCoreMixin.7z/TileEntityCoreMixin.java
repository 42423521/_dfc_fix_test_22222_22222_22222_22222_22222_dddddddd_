package com._test_ddddddd_.dfcfix.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.objectweb.asm.Opcodes;
import com._test_ddddddd_.dfcfix.ExplosionControl;

//@Mixin(targets = "com.hbm.tileentity.machine.TileEntityCore")


// 在文件顶部 import
import com.hbm.tileentity.machine.TileEntityCore;

// 把现有注解改为：
//@Mixin(TileEntityCore.class)

@Mixin(value = TileEntityCore.class, remap = false)

public abstract class TileEntityCoreMixin {
//    ...
//}






//    public class TileEntityCoreMixin {

    @Redirect(
        method = "update",
        at = @At(
            value = "FIELD",
            target = "Lcom/hbm/tileentity/machine/TileEntityCore;heat:I",//"Lcom/hbm/tileentity/machine/TileEntityCore;heat:I",
            opcode = Opcodes.GETFIELD
        )
    )
 //   private int redirectGetHeat(Object instance) {
  //      if (ExplosionControl.shouldDisable()) {
  //          return 0;
  //      }


    //private int redirectGetHeat(TileEntityCore instance) {
        //if (ExplosionControl.shouldDisable()) {
            //return 0;
        //}










    //private int redirectGetHeat(TileEntityCore instance) {







        //if (ExplosionControl.shouldDisable()) {
            //return 0;
        //}



    //private int redirectGetHeat(TileEntityCore instance) {


        //if (ExplosionControl.shouldDisable()) {
            //return 0;
        //}










     private int redirectGetHeat(TileEntityCore instance) {










        if (ExplosionControl.shouldDisable()) {
            return 0;
        }








        return instance.heat;

        try {
            java.lang.reflect.Field f = instance.getClass().getDeclaredField("heat");
            f.setAccessible(true);
            return f.getInt(instance);
        } catch (Exception e) {

            // 不要吞掉异常调试信息，改为打印到控制台方便排查（开发阶段）
            e.printStackTrace();

            return 0;
        }
    }






}
