package com._test_ddddddd_.dfcfix.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import com.hbm.tileentity.machine.TileEntityCore;
import com.hbm.inventory.fluid.tank.FluidTank;
import net.minecraft.nbt.NBTTagCompound;
import io.netty.buffer.ByteBuf;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/**
 * Mixin：确保 tile.getTileData().getInteger("tankCap") 可以改变实际 FluidTank 的容量（运行时）并截断超量液体。
 * 兼容性：尝试常见字段名和 setter 方法，尽量兼容 hbm 自定义的 FluidTank。
 */
@Mixin(value = TileEntityCore.class, remap = false)
public abstract class _t_d_d_d_d_d_d_d_{//TileEntityCoreTankMixin {

    @Shadow public FluidTank[] tanks; // shadow 目标类的字段

    static final String[] CANDIDATE_FIELD_NAMES = new String[] {
            "capacity", "maxFill", "max_fill", "maxFillAmount", "max", "maxAmount"
    };

    static final String[] CANDIDATE_SETTER_NAMES = new String[] {
            "setCapacity", "setMaxFill", "setMax", "setMaxAmount", "setCapacityMB"
    };

    // helper: 反射尝试把单个 tank 的容量改为 cap，并截断 amount
    private void applyCapacityToTank(FluidTank t, int cap) {
        if (t == null) return;
        try {
            // 1) 尝试调用 setter 方法
            for (String mname : CANDIDATE_SETTER_NAMES) {
                try {
                    Method m = t.getClass().getMethod(mname, int.class);
                    m.setAccessible(true);
                    m.invoke(t, cap);
                    // 截断当前 amount if necessary
                    try {
                        Method getFill = t.getClass().getMethod("getFill");
                        int now = (Integer) getFill.invoke(t);
                        if (now > cap) {
                            Method setFill = t.getClass().getMethod("setFill", int.class);
                            setFill.invoke(t, cap);
                        }
                    } catch (NoSuchMethodException nm) {
                        // 忽略
                    }
                    return;
                } catch (NoSuchMethodException ignore) { }
            }

            // 2) 尝试把常见的 int 字段写入
            for (String fname : CANDIDATE_FIELD_NAMES) {
                try {
                    Field f = t.getClass().getDeclaredField(fname);
                    f.setAccessible(true);
                    Class<?> ft = f.getType();
                    if (ft == int.class || ft == Integer.class) {
                        f.setInt(t, cap);
                        // 截断当前 amount if necessary (通过 setFill/getFill)
                        try {
                            Method getFill = t.getClass().getMethod("getFill");
                            int now = (Integer) getFill.invoke(t);
                            if (now > cap) {
                                Method setFill = t.getClass().getMethod("setFill", int.class);
                                setFill.invoke(t, cap);
                            }
                        } catch (NoSuchMethodException nm) {
                            // 忽略
                        }
                        return;
                    }
                } catch (NoSuchFieldException ignore) { }
            }

            // 3) 最后尝试直接使用 getMaxFill() 反推：如果类里有私有字段但名称不在名单里就无法设置 —— 只能尽力
            // 这里仅记录日志
            System.out.println("[DFCFIX] applyCapacityToTank: no setter/field found for " + t.getClass().getName());
        } catch (Throwable th) {
            th.printStackTrace();
        }
    }

    // 对 tanks[] 全部应用 cap（null-check）
    private void applyCapacityToAllTanks(int cap) {
        try {
            if (tanks == null) return;
            for (FluidTank t : tanks) {
                applyCapacityToTank(t, cap);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    // 注入 readFromNBT tail：从实体 NBT 或 tileData 恢复 tankCap，并应用到当前实例的 tanks
    @Inject(method = "readFromNBT", at = @At("TAIL"))
    private void onReadFromNBT(NBTTagCompound nbt, CallbackInfo ci) {
        try {
            int cap = 0;
            // 优先从 tileData（runtime 保存）读取：this.getTileData()
            // 但 mixin 里无法直接调用 getTileData() 安全访问，so 用 nbt 优先
            if(nbt != null && nbt.hasKey("tankCap")) {
                cap = nbt.getInteger("tankCap");
            }
            // apply if positive
            if (cap > 0) {
                applyCapacityToAllTanks(cap);
                System.out.println("[DFCFIX MIXIN] readFromNBT applied tankCap=" + cap);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    // 注入 writeToNBT tail：把当前 tileData 或当前 tanks capacity 写入实体 NBT（保证持久化）
    // Note: 目标类 writeToNBT 的签名是 writeToNBT(NBTTagCompound)
    @Inject(method = "writeToNBT", at = @At("RETURN"))
    private void onWriteToNBT(NBTTagCompound nbt, CallbackInfo ci) {
        try {
            int cap = 0;
            // 尝试从第一个 tank 的 capacity 读回一个合理值（反射）
            if (tanks != null && tanks.length > 0 && tanks[0] != null) {
                try {
                    Method getMaxFill = tanks[0].getClass().getMethod("getMaxFill");
                    Object o = getMaxFill.invoke(tanks[0]);
                    if (o instanceof Integer) cap = (Integer) o;
                } catch (NoSuchMethodException ns) {
                    // fallback: try common fields
                    for (String fname : CANDIDATE_FIELD_NAMES) {
                        try {
                            Field f = tanks[0].getClass().getDeclaredField(fname);
                            f.setAccessible(true);
                            Object val = f.get(tanks[0]);
                            if (val instanceof Integer) {
                                cap = (Integer) val;
                                break;
                            }
                        } catch (NoSuchFieldException ignore) {}
                    }
                }
            }
            if (cap > 0) {
                nbt.setInteger("tankCap", cap);
                System.out.println("[DFCFIX MIXIN] writeToNBT wrote tankCap=" + cap);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    // 注入 serialize tail (ByteBuf) —— 把 tankCap 写到网络包中，供 serialize/deserialize pair 使用
    @Inject(method = "serialize", at = @At("RETURN"))
    private void onSerialize(ByteBuf buf, CallbackInfo ci) {
        try {
            int cap = 0;
            if (tanks != null && tanks.length > 0 && tanks[0] != null) {
                try {
                    Method getMaxFill = tanks[0].getClass().getMethod("getMaxFill");
                    Object o = getMaxFill.invoke(tanks[0]);
                    if (o instanceof Integer) cap = (Integer) o;
                } catch (NoSuchMethodException ns) {
                    for (String fname : CANDIDATE_FIELD_NAMES) {
                        try {
                            Field f = tanks[0].getClass().getDeclaredField(fname);
                            f.setAccessible(true);
                            Object val = f.get(tanks[0]);
                            if (val instanceof Integer) {
                                cap = (Integer) val;
                                break;
                            }
                        } catch (NoSuchFieldException ignore) {}
                    }
                }
            }
            buf.writeInt(cap);
            System.out.println("[DFCFIX MIXIN] serialize wrote tankCap=" + cap);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    // 注入 deserialize tail (ByteBuf) —— 读回 tankCap 并应用到客户端实例
    @Inject(method = "deserialize", at = @At("RETURN"))
    private void onDeserialize(ByteBuf buf, CallbackInfo ci) {
        try {
            int cap = buf.readInt();
            if (cap > 0) {
                applyCapacityToAllTanks(cap);
                System.out.println("[DFCFIX MIXIN] deserialize applied tankCap=" + cap);
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}
