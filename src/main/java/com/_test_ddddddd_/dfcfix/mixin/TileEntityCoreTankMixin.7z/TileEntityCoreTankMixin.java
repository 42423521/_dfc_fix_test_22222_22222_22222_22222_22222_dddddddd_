





























package com._test_ddddddd_.dfcfix.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.hbm.tileentity.machine.TileEntityCore;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraftforge.fluids.FluidTank;
import net.minecraftforge.fluids.FluidStack;

import java.lang.reflect.Field;

@Mixin(value = TileEntityCore.class, remap = false)
public abstract class TileEntityCoreTankMixin {

    @Shadow public FluidTank[] tanks; // shadow 目标类的字段

    @Inject(method = "readFromNBT", at = @At("TAIL"))
    private void onReadFromNBT(NBTTagCompound nbt, CallbackInfo ci) {
        try {
            // tileData 中优先取 tankCap（如果命令写入了 tile.getTileData().setInteger("tankCap", v)）
            TileEntityCore self = (TileEntityCore)(Object)this;
            int cap = 128000; // 默认值和原代码一致
            if (self.getTileData() != null && self.getTileData().hasKey("tankCap")) {
                cap = self.getTileData().getInteger("tankCap");
            } else if (nbt.hasKey("tankCap")) {
                cap = nbt.getInteger("tankCap");
            }

            // 反射设置 FluidTank.capacity 字段
            Field capField = FluidTank.class.getDeclaredField("capacity");
            capField.setAccessible(true);
            for (FluidTank t : tanks) {
                if (t == null) continue;
                capField.setInt(t, cap);

                // 如果当前量大于新容量，则截断为新容量
                FluidStack fs = t.getFluid();
                if (fs != null && fs.amount > cap) {
                    t.setFluid(new FluidStack(fs.getFluid(), cap));
                }
            }

            System.out.println("[DFCFIX] applied tankCap=" + cap + " at " + self.getPos());
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    // 可选：在 networkUnpack 也保证客户端侧 tank 容量一致（如果你同步了 tankCap）
    @Inject(method = "networkUnpack", at = @At("TAIL"))
    private void onNetworkUnpack(NBTTagCompound data, CallbackInfo ci) {
        try {
            TileEntityCore self = (TileEntityCore)(Object)this;
            if (data.hasKey("tankCap")) {
                int cap = data.getInteger("tankCap");
                Field capField = FluidTank.class.getDeclaredField("capacity");
                capField.setAccessible(true);
                for (FluidTank t : tanks) {
                    if (t == null) continue;
                    capField.setInt(t, cap);
                }
                System.out.println("[DFCFIX] network applied tankCap=" + data.getInteger("tankCap") + " pos=" + self.getPos());
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }
}









//chonggaonm,(),

////////////////////////////////////////////////////////////////////////,(),
