








































































































































































































































































package com._test_ddddddd_.dfcfix.mixin;

import com.hbm.items.machine.ItemLens;
import com.hbm.packet.AuxGaugePacket;
import com.hbm.packet.PacketDispatcher;
import com.hbm.tileentity.TileEntityCore;
import com.hbm.tileentity.machine.TileEntityCoreStabilizer;
import com.hbm.tileentity.TileEntityMachineBase;
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////import com._test_ddddddd_.dfcfix.util.LensCompat;

import com._test_ddddddd_.dfcfix.util.fjdkls_dddddddddddd_grd_fdjkl_fwk_kal_kah_kill_all_human_ddddddd_;//.java

import api.hbm.energy.IEnergyUser;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.ITickable;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.fml.common.network.NetworkRegistry.TargetPoint;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

@Mixin(TileEntityCoreStabilizer.class)
public abstract class MixinTileEntityCoreStabilizer_rnm_xbd_rnm_s_long_h_s_x_d_new_y_y_dddddddd_ extends TileEntityMachineBase implements ITickable, IEnergyUser {

    // 保留父构造签名
    public MixinTileEntityCoreStabilizer() { super(1); }

    /**
     * 覆盖 update，来源基于原始实现，但把对 lens.maxDamage 的访问替换为 LensCompat.getMaxDamageSafe(...)
     * 目的：运行时无论字段存在/不存在/私有/方法式都能安全工作。
     */
    @Overwrite
    public void update() {
        if(!world.isRemote) {

            this.updateStandardConnections(world, pos);

            watts = MathHelper.clamp(watts, 1, 100);
            long demand = (long) Math.pow(watts, 6);
            isOn = false;

            beam = 0;

            ItemLens lens = null;
            if(inventory.getStackInSlot(0).getItem() instanceof ItemLens){
                lens = (ItemLens) inventory.getStackInSlot(0).getItem();
            }

            if(lens != null && power >= demand * lens.drainMod) {
                isOn = true;
                EnumFacing dir = EnumFacing.byIndex(this.getBlockMetadata());
                for(int i = 1; i <= range; i++) {

                    int x = pos.getX() + dir.getXOffset() * i;
                    int y = pos.getY() + dir.getYOffset() * i;
                    int z = pos.getZ() + dir.getZOffset() * i;
                    BlockPos pos1 = new BlockPos(x, y, z);

                    TileEntity te = world.getTileEntity(pos1);

                    if(te instanceof TileEntityCore) {

                        TileEntityCore core = (TileEntityCore)te;
                        core.field += (int)(watts * lens.fieldMod);
                        this.power -= (long)(demand * lens.drainMod);
                        beam = i;

                        long dmg = com.hbm.items.machine.ItemLens.getLensDamage(inventory.getStackInSlot(0));
                        dmg += watts;

                        // 关键：不直接访问 lens.maxDamage，调用兼容层
                        int max = fjdkls_dddddddddddd_grd_fdjkl_fwk_kal_kah_kill_all_human_ddddddd_.getMaxDamageSafe(lens, inventory.getStackInSlot(0)); //LensCompat.getMaxDamageSafe(lens, inventory.getStackInSlot(0));

                                     ////////////////////        fjdkls_dddddddddddd_grd_fdjkl_fwk_kal_kah_kill_all_human_ddddddd_.getMaxDamageSafe(lens, inventory.getStackInSlot(0)); //LensCompat.getMaxDamageSafe(lens, inventory.getStackInSlot(0));

                        if(dmg >= max)
                            inventory.setStackInSlot(0, ItemStack.EMPTY);
                        else
                            com.hbm.items.machine.ItemLens.setLensDamage(inventory.getStackInSlot(0), dmg);

                        break;
                    }

                    if(te instanceof TileEntityCoreStabilizer)
                        continue;

                    if(world.getBlockState(pos1).getBlock() != Blocks.AIR)
                        break;
                }
            }

            PacketDispatcher.wrapper.sendToAllTracking(new AuxGaugePacket(pos, beam, 0), new TargetPoint(world.provider.getDimension(), pos.getX(), pos.getY(), pos.getZ(), 250));
        }
    }

    // 其余方法如 networkUnpack、readFromNBT、writeToNBT 等不变：不必覆盖
}
