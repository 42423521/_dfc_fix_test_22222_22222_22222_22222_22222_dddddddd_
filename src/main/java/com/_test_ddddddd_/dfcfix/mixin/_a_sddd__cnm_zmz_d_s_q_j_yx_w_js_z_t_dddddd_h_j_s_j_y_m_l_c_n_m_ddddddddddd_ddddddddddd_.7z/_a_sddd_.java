import com._test_ddddddd_.dfcfix._lx_s_q_j_dddddddd_;//.java//.debug.StabilizerDebug;
import com.hbm.tileentity.machine.TileEntityCoreStabilizer;


import org.spongepowered.asm.mixin.Mixin;







import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;



import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;



//狗日的      尼玛还是       mixin                                                                                                                                        的,(),             ,(),





@Mixin(TileEntityCoreStabilizer.class)
public abstract class _a_sddd_{//////////////////////////////.java//TileEntityCoreStabilizerMixin {

    @Inject(method = "update", at = @At("HEAD"))
    private void beforeUpdate(CallbackInfo ci) {
        // 调用外部调试类
        StabilizerDebug.logLens((TileEntityCoreStabilizer)(Object)this);
    }
}
