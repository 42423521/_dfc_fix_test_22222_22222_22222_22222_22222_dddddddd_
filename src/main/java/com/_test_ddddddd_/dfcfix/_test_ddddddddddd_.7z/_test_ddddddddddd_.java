


















// 需要的 import（放文件头）：
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

// 在命令处理里调用： applyTankCapRealtime(te, world, pos, tankCap);
public static void applyTankCapRealtime(Object tileEntityCoreObj, World world, BlockPos pos, int tankCap) {
    try {
        // --- 持久化写入 tileData 并通知客户端刷新 ---
        try {
            // tileEntityCoreObj 典型是 com.hbm.tileentity.machine.TileEntityCore
            Method getTileData = tileEntityCoreObj.getClass().getMethod("getTileData");
            Object tileData = getTileData.invoke(tileEntityCoreObj);
            if (tileData != null) {
                Method setInteger = tileData.getClass().getMethod("setInteger", String.class, int.class);
                setInteger.invoke(tileData, "tankCap", tankCap);
            }
            // markDirty
            try {
                Method markDirty = tileEntityCoreObj.getClass().getMethod("markDirty");
                markDirty.invoke(tileEntityCoreObj);
            } catch (NoSuchMethodException ignore) {}
            // notify block update to force client refresh (best-effort)
            if (world != null && pos != null) {
                IBlockState s = world.getBlockState(pos);
                world.notifyBlockUpdate(pos, s, s, 3);
            }
        } catch (NoSuchMethodException nsme) {
            // 目标类没有 getTileData()? 忽略持久化步骤（尽力而为）
            nsme.printStackTrace();
        }

        // --- 运行时修改实际 tanks 实例（优先官方 Forge FluidTank） ---
        // 先通过反射取出 tileEntityCoreObj.tanks 字段（数组）
        Object[] tanksArr = null;
        String[] tankFieldNames = new String[] {"tanks", "fluidTanks", "tankArray"};
        for (String name : tankFieldNames) {
            try {
                Field f = tileEntityCoreObj.getClass().getDeclaredField(name);
                f.setAccessible(true);
                Object arr = f.get(tileEntityCoreObj);
                if (arr != null) {
                    int len = Array.getLength(arr);
                    tanksArr = new Object[len];
                    for (int i = 0; i < len; i++) tanksArr[i] = Array.get(arr, i);
                }
                break;
            } catch (NoSuchFieldException ignore) {}
        }

        if (tanksArr == null) {
            // 没找到 tanks 字段，尝试通过 getter 方法（备选）
            try {
                Method getTanks = tileEntityCoreObj.getClass().getMethod("getTanks");
                Object arr = getTanks.invoke(tileEntityCoreObj);
                if (arr != null) {
                    int len = Array.getLength(arr);
                    tanksArr = new Object[len];
                    for (int i = 0; i < len; i++) tanksArr[i] = Array.get(arr, i);
                }
            } catch (Throwable ignore) {}
        }

        if (tanksArr == null) {
            System.out.println("[DFCFIX CMD] no tanks array found on TileEntityCore, nothing applied.");
            return;
        }

        // 候选名（官方优先）
        String[] capSetters = new String[] {"setCapacity", "setMaxFill", "setMax", "setMaxAmount", "setCapacityMB"};
        String[] capFields = new String[] {"capacity", "maxFill", "max_fill", "maxFillAmount", "max", "maxAmount"};
        String[] getFillNames = new String[] {"getFill", "getFluidAmount", "getAmount"};
        String[] setFillNames = new String[] {"setFill", "setFluidAmount", "setAmount"};
        String[] getCapacityNames = new String[] {"getMaxFill", "getCapacity", "getMax"};

        for (Object tank : tanksArr) {
            if (tank == null) continue;
            boolean applied = false;

            // 1) 官方 path：如果是 net.minecraftforge.fluids.FluidTank，直接用其字段/方法（反射，不需要在编译期 import）
            try {
                Class<?> forgeTankCls = Class.forName("net.minecraftforge.fluids.FluidTank");
                if (forgeTankCls.isAssignableFrom(tank.getClass())) {
                    // set protected int capacity via reflection
                    try {
                        Field capField = forgeTankCls.getDeclaredField("capacity");
                        capField.setAccessible(true);
                        capField.setInt(tank, tankCap);
                    } catch (NoSuchFieldException ignore) {}

                    // clamp FluidStack.amount if necessary
                    try {
                        Method getFluid = forgeTankCls.getMethod("getFluid");
                        Object fs = getFluid.invoke(tank); // net.minecraftforge.fluids.FluidStack
                        if (fs != null) {
                            Class<?> fsCls = Class.forName("net.minecraftforge.fluids.FluidStack");
                            Field amtF = null;
                            try {
                                amtF = fsCls.getDeclaredField("amount");
                                amtF.setAccessible(true);
                                int now = amtF.getInt(fs);
                                if (now > tankCap) {
                                    // construct new FluidStack with same fluid and cap
                                    Method getFluidMeth = fsCls.getMethod("getFluid");
                                    Object fluidObj = getFluidMeth.invoke(fs);
                                    Object newFs = fsCls.getConstructor(fluidObj.getClass(), int.class).newInstance(fluidObj, tankCap);
                                    Method setFluid = forgeTankCls.getMethod("setFluid", fsCls);
                                    setFluid.invoke(tank, newFs);
                                }
                            } catch (NoSuchFieldException nf) {
                                // 如果没有 amount 字段（极不可能），忽略
                            }
                        }
                    } catch (NoSuchMethodException ignore) {}

                    applied = true;
                }
            } catch (ClassNotFoundException cnf) {
                // 没有 Forge FluidTank 类（极小概率，dev env 有），继续反射回退
            } catch (Throwable t) {
                t.printStackTrace();
            }

            if (applied) continue;

            // 2) 通用反射路径：先尝试 setter 方法
            Class<?> cls = tank.getClass();
            try {
                for (String mname : capSetters) {
                    try {
                        Method m = cls.getMethod(mname, int.class);
                        m.setAccessible(true);
                        m.invoke(tank, tankCap);
                        applied = true;
                        break;
                    } catch (NoSuchMethodException ignore) {}
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }

            // 3) 若没有 setter，再尝试字段
            if (!applied) {
                try {
                    for (String fname : capFields) {
                        try {
                            Field ff = cls.getDeclaredField(fname);
                            ff.setAccessible(true);
                            ff.setInt(tank, tankCap);
                            applied = true;
                            break;
                        } catch (NoSuchFieldException ignore) {}
                    }
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }

            // 4) 截断当前量（优先使用 getFill/setFill）
            try {
                Integer now = null;
                for (String g : getFillNames) {
                    try {
                        Method gm = cls.getMethod(g);
                        gm.setAccessible(true);
                        Object v = gm.invoke(tank);
                        if (v instanceof Integer) { now = (Integer) v; break; }
                    } catch (NoSuchMethodException ignore) {}
                }
                if (now != null && now > tankCap) {
                    for (String s : setFillNames) {
                        try {
                            Method sm = cls.getMethod(s, int.class);
                            sm.setAccessible(true);
                            sm.invoke(tank, tankCap);
                            now = tankCap;
                            break;
                        } catch (NoSuchMethodException ignore) {}
                    }
                    if (now != tankCap) {
                        // 最后尝试写 amount/ fill 字段
                        String[] amtFields = new String[] {"amount", "fill", "fluidAmount"};
                        for (String af : amtFields) {
                            try {
                                Field f = cls.getDeclaredField(af);
                                f.setAccessible(true);
                                f.setInt(tank, tankCap);
                                break;
                            } catch (NoSuchFieldException ignore) {}
                        }
                    }
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }

            // 记录结果（方便 debug）
            if (applied) {
                System.out.println("[DFCFIX CMD] applied tankCap to tank class " + tank.getClass().getName() + " cap=" + tankCap);
            } else {
                System.out.println("[DFCFIX CMD] failed to apply direct cap to tank class " + tank.getClass().getName() + " (will persist via NBT)");
            }
        }

        System.out.println("[DFCFIX CMD] finished applyTankCapRealtime = " + tankCap + " at " + (pos == null ? "?" : pos.toString()));
    } catch (Throwable ex) {
        ex.printStackTrace();
    }
}
