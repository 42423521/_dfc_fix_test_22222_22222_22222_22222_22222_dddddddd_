package com._test_ddddddd_.dfcfix.mixin;

import net.minecraft.tileentity.TileEntity;
import org.spongepowered.asm.mixin.Mixin;

/**
 * 一个安全的空 mixin（仅声明目标类）。
 * 如果你要在这里注入/重写方法，请谨慎修改并测试。
 */
@Mixin(TileEntity.class)
public abstract class TileEntityCoreMixin {
    // 目前不做任何注入 —— 危险操作请先在单独环境里测试
}
