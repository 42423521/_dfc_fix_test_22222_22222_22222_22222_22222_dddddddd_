package com._test_ddddddd_.dfcfix;

import com._test_ddddddd_.dfcfix.dfcmod.DfcMixinLoader;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;
import net.minecraftforge.fml.common.event.FMLServerStartingEvent;
import com._test_ddddddd_.dfcfix.command.CommandDfcFix;

@Mod(modid = TestMod.MODID, name = "DFC Fix", version = TestMod.VERSION, acceptableRemoteVersions = "*")
public class TestMod {
    public static final String MODID = "dfcfix";
    // Gradle 可以替换这个字符串，或者你自己修改
    public static final String VERSION = "0.0.1";

    @EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        // 初始化 mixin（如果有 mixin）
        DfcMixinLoader.init();

        // 注册事件总线里的爆炸控制
        MinecraftForge.EVENT_BUS.register(new ExplosionControl());
    }

    @EventHandler
    public void serverStarting(FMLServerStartingEvent event) {
        // 注册服务器命令
        event.registerServerCommand(new CommandDfcFix());
    }
}
